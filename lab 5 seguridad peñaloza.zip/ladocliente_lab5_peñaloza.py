import socket
import pickle
import random
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding

def generar_claves():
    p = 601  
    g = 203   
    b = random.randint(1, p - 1)  
    B = (g ** b) % p  
    return p, g, b, B

def intercambiar_claves_cliente(B_servidor, p, b):
    s = (B_servidor ** b) % p  
    return s


client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 12345))


p, g, b, B = generar_claves()

print(f"Clave pública del cliente (B): {B}")
client_socket.send(pickle.dumps(B))
A_servidor = pickle.loads(client_socket.recv(1024))

clave_secreta = intercambiar_claves_cliente(A_servidor, p, b)
print(f"Clave secreta compartida: {clave_secreta}")


clave_des = b'MiClave8'


cipher = Cipher(algorithms.TripleDES(clave_des), modes.ECB(), backend=default_backend())
encryptor = cipher.encryptor()


padder = padding.PKCS7(64).padder()
padded_data = padder.update(pickle.dumps(B)) + padder.finalize()
B_cifrado = encryptor.update(padded_data) + encryptor.finalize()


client_socket.send(clave_des)


client_socket.send(B_cifrado)

client_socket.close()