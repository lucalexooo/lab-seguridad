import socket
import socket
import pickle
import random
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding

def generar_claves():
    p = 601  
    g = 203   
    a = random.randint(1, p - 1)  
    A = (g ** a) % p  
    return p, g, a, A

def intercambiar_claves_servidor(A_cliente, p, a):
    s = (A_cliente ** a) % p  
    return s


server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(1)

print("Esperando conexión...")

conn, addr = server_socket.accept()
print("Conexión establecida desde:", addr)


p, g, a, A = generar_claves()

print(f"Clave pública del servidor (A): {A}")
A_cliente = pickle.loads(conn.recv(1024))
conn.send(pickle.dumps(A))



clave_des = conn.recv(8)


cipher = Cipher(algorithms.TripleDES(clave_des), modes.ECB(), backend=default_backend())
decryptor = cipher.decryptor()


B_cifrado = conn.recv(1024)


with open("mensajeentrada.txt", "wb") as file:
    file.write(B_cifrado)


with open("mensajeentrada.txt", "rb") as file:
    B_cifrado2 = file.read()

B_bytes = decryptor.update(B_cifrado2) + decryptor.finalize()
unpadder = padding.PKCS7(64).unpadder()
B_bytes_unpadded = unpadder.update(B_bytes) + unpadder.finalize()
B_recibido = pickle.loads(B_bytes_unpadded)



unpadder = padding.PKCS7(64).unpadder()
B_bytes_unpadded = unpadder.update(B_bytes) + unpadder.finalize()
B = pickle.loads(B_bytes_unpadded)


with open("mensajerecibido.txt", "w") as file:
    file.write(str(B))


with open("mensajerecibido.txt", "r") as file:
    B_txt = int(file.read())

print(f"B recibido y descifrado: {B_txt}")

clave_secreta_calculada = intercambiar_claves_servidor(B_txt, p, a)
print(f"Clave secreta compartida: {clave_secreta_calculada}")

conn.close()
server_socket.close()
