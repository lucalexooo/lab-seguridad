import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding

def generate_key_pair():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    return private_key, public_key

def save_key_to_file(key, filename):
    with open(filename, 'wb') as f:
        f.write(key)

def load_key_from_file(filename):
    with open(filename, 'rb') as f:
        key_data = f.read()
    return key_data

def main():
    # Configuración del servidor
    host = '127.0.0.1'
    port = 12345

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen()

    print(f"Servidor escuchando en {host}:{port}")

    # Generar y guardar la clave pública del servidor
    private_key, public_key = generate_key_pair()
    save_key_to_file(public_key, 'server_public_key.pem')

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexión establecida desde {addr}")

        # Enviar la clave pública al cliente
        client_socket.send(public_key)

        # Recibir la clave pública del cliente
        client_public_key_data = client_socket.recv(4096)
        client_public_key = load_key_from_file('client_public_key.pem')
        
        # Recibir el archivo cifrado desde el cliente
        encrypted_data = client_socket.recv(4096)
        
        # Descifrar el archivo con la clave privada del servidor
        decrypted_data = private_key.decrypt(
            encrypted_data,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # Guardar el archivo descifrado
        with open('mensajerecibido.txt', 'wb') as f:
            f.write(decrypted_data)

        print("Archivo recibido y descifrado correctamente")

        client_socket.close()

if __name__ == "__main__":
    main()