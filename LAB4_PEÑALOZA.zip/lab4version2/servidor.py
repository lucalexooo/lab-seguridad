import socket
import rsa

# Generar claves RSA
(clave_publica, clave_privada) = rsa.newkeys(512)

# Configuración del servidor
host = '127.0.0.1'
puerto = 12345

# Crear socket del servidor
socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_servidor.bind((host, puerto))
socket_servidor.listen(1)

print(f"Esperando conexiones en {host}:{puerto}...")

# Esperar a que un cliente se conecte
socket_cliente, direccion_cliente = socket_servidor.accept()
print(f"Conexión establecida desde {direccion_cliente}")

# Enviar clave pública al cliente
clave_publica_bytes = clave_publica.save_pkcs1()
socket_cliente.send(clave_publica_bytes)

# Recibir mensaje cifrado
texto_cifrado = socket_cliente.recv(1024)

# Desencriptar el mensaje
mensaje_desencriptado = rsa.decrypt(texto_cifrado, clave_privada).decode('utf-8')

# Guardar el mensaje en un archivo
with open('mensajerecibido.txt', 'w') as archivo:
    archivo.write(mensaje_desencriptado)

print("Mensaje recibido y desencriptado. Consulta 'mensajerecibido.txt'")
socket_cliente.close()
socket_servidor.close()