import socket
import rsa


host = '127.0.0.1'
port = 12345


socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket_cliente.connect((host, port))


clave_publica_servidor_bytes = socket_cliente.recv(1024)
clave_publica_servidor = rsa.PublicKey.load_pkcs1(clave_publica_servidor_bytes)


with open('mensajeentrada.txt', 'r') as archivo:
    mensaje = archivo.read()


texto_cifrado = rsa.encrypt(mensaje.encode('utf-8'), clave_publica_servidor)


socket_cliente.send(texto_cifrado)

print("Mensaje cifrado enviado al servidor.")
socket_cliente.close()
