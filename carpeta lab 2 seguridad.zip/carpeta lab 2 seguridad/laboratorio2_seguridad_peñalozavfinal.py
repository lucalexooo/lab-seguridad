import hashlib

# cifrados vigenere y rot_n + descifrado rot_n
def cifrado_vigenere(texto, clave):
    resultado = []
    clave_repetida = clave * (len(texto) // len(clave)) + clave[:len(texto) % len(clave)]

    for i in range(len(texto)):
        if 'a' <= texto[i] <= 'z':
            offset = ord('a')
            resultado.append(chr(((ord(texto[i]) - offset + ord(clave_repetida[i]) - offset) % 26) + offset))
        elif 'A' <= texto[i] <= 'Z':
            offset = ord('A')
            resultado.append(chr(((ord(texto[i]) - offset + ord(clave_repetida[i]) - offset) % 26) + offset))
        else:
            resultado.append(texto[i])
    return ''.join(resultado)

def cifrado_rotn(texto, n):
    resultado = []
    for caracter in texto:
        if 'a' <= caracter <= 'z':
            offset = ord('a')
            resultado.append(chr(((ord(caracter) - offset + n) % 26) + offset))
        elif 'A' <= caracter <= 'Z':
            offset = ord('A')
            resultado.append(chr(((ord(caracter) - offset + n) % 26) + offset))
        else:
            resultado.append(caracter)
    return ''.join(resultado)

def descifrado_rotn(texto_cifrado, n):
    return cifrado_rotn(texto_cifrado, -n)

# Función para generar el hash del archivo de texto
def generar_hash2(text):
    hash_object = hashlib.sha256(text.encode())
    return hash_object.hexdigest()

# Archivo de entrada
archivo_entrada = "mensajedeentrada.txt"

# Archivo de salida
archivo_salida = "mensajeseguro.txt"

# Clave para el cifrado Vigenère
clave = "cvqnoteshrwnszhhksorbqcosa"

# Leer el mensaje de entrada
with open(archivo_entrada, "r") as f:
    mensaje = f.read()

# Generar el hash del mensaje cifrado
hash_cifrado = hashlib.sha256(mensaje.encode()).hexdigest()


#------------------------------------DESCIFRADO DEL MENSAJE--------------------------------------------------------------------# 

def descifrado_vigenere(texto_cifrado, clave):
    resultado = []
    clave_repetida = clave * (len(texto_cifrado) // len(clave)) + clave[:len(texto_cifrado) % len(clave)]

    for i in range(len(texto_cifrado)):
        if 'a' <= texto_cifrado[i] <= 'z':
            offset = ord('a')
            resultado.append(chr(((ord(texto_cifrado[i]) - ord(clave_repetida[i]) + 26) % 26) + offset))
        elif 'A' <= texto_cifrado[i] <= 'Z':
            offset = ord('A')
            resultado.append(chr(((ord(texto_cifrado[i]) - ord(clave_repetida[i]) + 26) % 26) + offset))
        else:
            resultado.append(texto_cifrado[i])
    return ''.join(resultado)
#cifrados= rot14, rot7 y vigenere
mensaje_rot14 = cifrado_rotn(mensaje,14)
print("Rot14:", mensaje_rot14)

mensaje_vigenere = cifrado_vigenere(mensaje_rot14, "cvqnoteshrwnszhhksorbqcosa")
print("Vigenere:", mensaje_vigenere)

mensaje_rot7 = cifrado_rotn(mensaje_vigenere, 7)
print("Rot7:", mensaje_rot7)

#escribe y lee el mensaje
with open("mensajeseguro.txt", "w") as f:
    f.write(mensaje_rot7)

with open("mensajeseguro.txt", "r") as d:
    leer_codigo=d.read()
#descifrar el mensaje    
print(leer_codigo)
mensajee = descifrado_rotn(leer_codigo, 7)
mensaje_vigenere = descifrado_vigenere(mensajee, "cvqnoteshrwnszhhksorbqcosa")
mensaje_rot14 = descifrado_rotn(mensaje_vigenere, 14)
print("Mensaje descifrado:", mensaje_rot14)
# genera el hash al mensaje descifrado
mensajee2= generar_hash2(mensaje_rot14)
print(mensajee2)
print(hash_cifrado)
if hash_cifrado==mensajee2:
    print("los dos mensajes son iguales")






